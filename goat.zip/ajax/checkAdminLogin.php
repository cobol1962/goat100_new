 <?php 

 include($_SERVER["DOCUMENT_ROOT"] . "/include/database.php"); 
	if ($_POST["username"] == "asdrfGHyuiJKL" && $_POST["password"] == "xxCVGwerfbddd") {
		echo "1";
	} else {
		echo "0";
	}
 ?>