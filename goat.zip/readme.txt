Gallery
Made by Alan Chang
Materializecss.com

-------------------

Personal Use License

All themes are under the Personal Use License meaning you can use and modify these themes for personal and client projects. You cannot redistribute or resell these themes in any way.

-------------------

Support

All themes come with active support. Send your questions and concerns to materializethemes@gmail.com</a>

-------------------

Sass Compilation

Sass compilation is exactly the same as what is used for Materialize. Install all the npm dependencies in the theme folder and then use grunt monitor to automatically compile changes to your files.