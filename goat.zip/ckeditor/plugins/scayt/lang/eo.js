﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'eo', {
	btn_about: 'Pri OKDVT',
	btn_dictionaries: 'Vortaroj',
	btn_disable: 'Malebligi OKDVT',
	btn_enable: 'Ebligi OKDVT',
	btn_langs:'Lingvoj',
	btn_options: 'Opcioj',
	text_title:  'OrtografiKontrolado Dum Vi Tajpas (OKDVT)'
});
