﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'fr', {
	btn_about: 'A propos de SCAYT',
	btn_dictionaries: 'Dictionnaires',
	btn_disable: 'Désactiver SCAYT',
	btn_enable: 'Activer SCAYT',
	btn_langs:'Langues',
	btn_options: 'Options',
	text_title: 'Vérification de l\'Orthographe en Cours de Frappe (SCAYT)'
});
